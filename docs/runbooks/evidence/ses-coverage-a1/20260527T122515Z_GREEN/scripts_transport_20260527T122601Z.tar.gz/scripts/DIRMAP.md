<!-- [scrai:start] -->
## scripts

| File | Summary |
| --- | --- |
| api-dev.sh | Stub summary for api-dev.sh. |
| audit_secrets.sh | Stub summary for audit_secrets.sh. |
| bootstrap-env-local.sh | bootstrap-env-local.sh — Generate .env.local from .env.local.example and
the external secret source.

Resolution order for each key:
  1. |
| check-sizes.sh | Enforce hard file-size limits for source files.

Limits are calibrated to flag genuinely-too-large source files while
accommodating the line-count overhead that `prettier --write` adds when
breaking long lines into multi-line form. |
| customer_broadcast.sh | customer_broadcast.sh — operator wrapper for POST /admin/broadcast. |
| deploy_status.sh | deploy_status.sh — one-screen answer to "what's deployed?"

Probes /version on the live API, compares dev_sha against `git rev-parse main`
in the dev repo, and shows the gap. |
| e2e-preflight.sh | Stub summary for e2e-preflight.sh. |
| git_push_with_sync.sh | Wrap git push with best-effort mirror sync on main. |
| integration-down.sh | integration-down.sh — Tear down the integration test stack.

Kills API + flapjack processes, drops test DB, cleans up PID files.
Idempotent: safe to run even when nothing is running. |
| integration-test.sh | integration-test.sh — Run integration tests against an isolated stack.

Brings up the integration stack, runs tests with INTEGRATION=1, then tears down.
The stack is always torn down on exit (via trap). |
| integration-up.sh | integration-up.sh — Bring up an isolated integration test stack.

Creates fjcloud_integration_test DB, runs migrations, builds binaries,
starts flapjack on port 7799, starts fjcloud API on port 3099, health-checks both.

Prerequisites: Postgres 16 running locally, flapjack_dev repo at FLAPJACK_DEV_DIR. |
| live-backend-gate.sh | Backend launch gate — orchestrates all required backend validation checks
and produces a machine-readable JSON summary.

Usage:
  scripts/live-backend-gate.sh [--skip-rust-tests] [--fail-fast]

Options:
  --skip-rust-tests  Skip Rust validation tests (cargo test)
  --fail-fast        Stop on first check failure

Output:
  stdout: JSON summary with check_results, reason codes, and timing
  stderr: Per-check progress (always printed)

Exit codes:
  0 — all checks passed (or were skipped in dev mode)
  1 — one or more actionable gate failures

Environment:
  GATE_CHECK_TIMEOUT_SEC  Per-check timeout in seconds (default: 30). |
| local-ci.sh | # HELP-TEXT-BEGIN
local-ci.sh — Run every gate the staging deploy-staging job depends on,
locally, in parallel where safe. |
| local-dev-down.sh | local-dev-down.sh — Tear down local dev services.

Kills flapjack, stops Docker Compose, cleans up PID/log files.
Idempotent: safe to run even when nothing is running.

Usage:
  scripts/local-dev-down.sh           # stop services, keep data
  scripts/local-dev-down.sh --clean   # stop services and remove volumes. |
| local-dev-migrate.sh | local-dev-migrate.sh — Apply database migrations for local development.

Prerequisites: source .env.local first to set DATABASE_URL.
Not safely rerunnable — migrations are not uniformly idempotent.
To reset, drop the database and re-create it before running again. |
| local-dev-up.sh | local-dev-up.sh — Start the local development environment.

Starts Docker Compose Postgres, runs migrations, starts Flapjack on port 7700,
and prints instructions for starting the API and web processes manually.

Prerequisites: docker, curl, .env.local at repo root.
Optional: FLAPJACK_DEV_DIR pointing to flapjack_dev repo. |
| local-signoff-cold-storage.sh | local-signoff-cold-storage.sh — Thin env bridge + cargo test delegate for
cold-storage integration signoff.

Resolves strict local stack defaults, validates cold-storage prerequisites,
delegates to the authoritative Rust integration test, and emits JSON +
operator-readable evidence.

Usage:
  ./scripts/local-signoff-cold-storage.sh. |
| local-signoff-commerce.sh | local-signoff-commerce.sh — Strict local commerce proof runner.

Exercises the full local commerce lane: signup -> email verification ->
batch billing -> invoice payment. |
| local-signoff.sh | local-signoff.sh — Top-level orchestrator that delegates to commerce,
cold-storage, and HA proof-owner scripts in strict order.

Does NOT duplicate proof-owner internals — only calls the three scripts
and interprets exit codes/output. |
| local_demo.sh | One-command local demo launcher: infra + API + web + seed data + metering. |
| playwright_local_stack.sh | Stub summary for playwright_local_stack.sh. |
| probe_alert_delivery.sh | Stub summary for probe_alert_delivery.sh. |
| probe_cloudflare_ai_block.sh | Read-only Cloudflare AI-bot-protection probe. |
| probe_deployed_signup_renders.sh | Stub summary for probe_deployed_signup_renders.sh. |
| probe_live_state.sh | scripts/probe_live_state.sh — fjcloud realization of Live State Discipline.

Per-project read-only inventory probe. |
| probe_organic_alert_dispatch.sh | Stub summary for probe_organic_alert_dispatch.sh. |
| probe_ses_bounce_complaint_e2e.sh | Stub summary for probe_ses_bounce_complaint_e2e.sh. |
| probe_ses_simulator_send.sh | Send-only SES mailbox simulator probe for bounce/complaint proof. |
| run-aggregation-job.sh | run-aggregation-job.sh — Run the aggregation job for a target date.

Rolls up raw usage_records into daily aggregates in usage_daily.
Idempotent — safe to run multiple times for the same date.
Defaults to yesterday (UTC) when no date argument is provided.

Usage:
  scripts/run-aggregation-job.sh                # yesterday
  scripts/run-aggregation-job.sh 2026-03-27     # specific date. |
| seed_local.sh | seed_local.sh — Idempotent local development seed script.

Creates a test user, index, and optionally seeds search data.
Safe to run multiple times — skips resources that already exist.

Usage:
  ./scripts/seed_local.sh              # uses defaults from .env.local
  API_URL=http://localhost:3001 ADMIN_KEY=my-key ./scripts/seed_local.sh. |
| seed_operator_accounts.sh | Stub summary for seed_operator_accounts.sh. |
| staging_billing_dry_run.sh | Stub summary for staging_billing_dry_run.sh. |
| staging_billing_rehearsal.sh | staging_billing_rehearsal.sh — guarded staging billing mutation rehearsal. |
| start-metering.sh | start-metering.sh — Start the metering agent for local dev.

Must run AFTER seed_local.sh (needs a real customer UUID from the database).
The metering agent scrapes Flapjack /metrics, computes deltas, and writes
usage_records to Postgres. |
| stripe_cutover_prereqs.sh | Stub summary for stripe_cutover_prereqs.sh. |
| stripe_webhook_replay_fixture.sh | Stub summary for stripe_webhook_replay_fixture.sh. |
| validate-metering.sh | Validate metering pipeline health against a live database and emit JSON. |
| validate-stripe.sh | Stub summary for validate-stripe.sh. |
| validate_customer_quickstart.sh | Stub summary for validate_customer_quickstart.sh. |
| validate_full_vm_lifecycle_prod.sh | Stub summary for validate_full_vm_lifecycle_prod.sh. |
| validate_inbound_email_roundtrip.sh | Validate SES outbound-to-inbound roundtrip for the shared test inbox path. |
| validate_oauth_routes.sh | Stub summary for validate_oauth_routes.sh. |
| validate_ses_readiness.sh | Stub summary for validate_ses_readiness.sh. |
| validate_staging_dunning_delivery.sh | Validate staging dunning email delivery by reusing rehearsal artifacts and SES inbound S3 evidence. |
| validate_subprocessor_disclosure.sh | Stub summary for validate_subprocessor_disclosure.sh. |
| web-dev.sh | web-dev.sh — Start the SvelteKit dev server with repo-local auth env loaded. |

| Directory | Summary |
| --- | --- |
| canary | The canary directory contains synthetic monitoring scripts and contract tests that verify system health, external dependencies, and customer-facing flows. |
| chaos | The chaos directory contains automated failure injection and HA failover tests that simulate region outages, kill primary VMs, and verify system recovery and failover behavior. |
| dev | Migrates Rust integration test files from infra/api/tests/ to infra/api/tests/integration/ and rewrites their module paths from local declarations to absolute crate references. |
| launch | The `scripts/launch/` directory contains operational scripts for deployment verification, staging validation, and synthetic traffic testing during the fjcloud launch process. |
| lib | Reusable shell script helpers used by fjcloud integration tests and operational scripts to provide common functionality like alert dispatch, database operations, API interactions, and validation checks. |
| load | The load directory contains utilities for load testing and regression analysis, with a lib/ subdirectory providing tools to compare offline and live load harness results. |
| reliability | This directory provides shell scripts for capacity profiling, reliability testing, and security validation of the backend system across three document tier sizes (1k, 10k, 100k documents). |
| stripe | This directory contains Stripe configuration automation scripts that set up and manage the billing portal and product catalog for specific Stripe accounts, with support for multi-account environments via environment variable namespacing. |
| tests | This directory contains shell script-based smoke tests and integration test utilities for validating fjcloud's ops-layer functionality, including customer broadcast handling and SES bounce/complaint workflows. |
| vlm | This directory contains Visual Language Model (VLM) operations scripts for bundling and aggregating verdict outputs, along with shell utilities for environment configuration and prompt evaluation. |
| w3_triage | W3 triage is an automated system for processing audit recommendations and coordinating rule application through preflight state discovery, recommendation parsing, and dispatch manifest generation. |
<!-- [scrai:end] -->
