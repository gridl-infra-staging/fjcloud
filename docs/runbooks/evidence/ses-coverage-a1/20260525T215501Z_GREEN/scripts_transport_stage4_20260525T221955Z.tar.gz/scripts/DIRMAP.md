<!-- [scrai:start] -->
## scripts

| File | Summary |
| --- | --- |
| api-dev.sh | api-dev.sh — Start the API with repo-local env files exported. |
| audit_secrets.sh | Stub summary for audit_secrets.sh. |
| bootstrap-env-local.sh | bootstrap-env-local.sh — Generate .env.local from .env.local.example and
the external secret source.

Resolution order for each key:
  1. |
| check-sizes.sh | Enforce hard file-size limits for source files.

Limits are calibrated to flag genuinely-too-large source files while
accommodating the line-count overhead that `prettier --write` adds when
breaking long lines into multi-line form. |
| customer_broadcast.sh | customer_broadcast.sh — operator wrapper for POST /admin/broadcast. |
| deploy_status.sh | deploy_status.sh — one-screen answer to "what's deployed?"

Probes /version on the live API, compares dev_sha against `git rev-parse main`
in the dev repo, and shows the gap. |
| e2e-preflight.sh | Preflight checks for Stage 6 browser (Playwright) test runs.
Validates that required environment variables and services are available
before invoking Playwright, to produce clear errors instead of cryptic failures.

Loads .env.local via the shared env parser so that ADMIN_KEY and other
local-dev values are available without manual exports. |
| git_push_with_sync.sh | Wrap git push with best-effort mirror sync on main. |
| integration-down.sh | integration-down.sh — Tear down the integration test stack.

Kills API + flapjack processes, drops test DB, cleans up PID files.
Idempotent: safe to run even when nothing is running. |
| integration-test.sh | integration-test.sh — Run integration tests against an isolated stack.

Brings up the integration stack, runs tests with INTEGRATION=1, then tears down.
The stack is always torn down on exit (via trap). |
| integration-up.sh | integration-up.sh — Bring up an isolated integration test stack.

Creates fjcloud_integration_test DB, runs migrations, builds binaries,
starts flapjack on port 7799, starts fjcloud API on port 3099, health-checks both.

Prerequisites: Postgres 16 running locally, flapjack_dev repo at FLAPJACK_DEV_DIR. |
| live-backend-gate.sh | Backend launch gate — orchestrates all required backend validation checks
and produces a machine-readable JSON summary.

Usage:
  scripts/live-backend-gate.sh [--skip-rust-tests] [--fail-fast]

Options:
  --skip-rust-tests  Skip Rust validation tests (cargo test)
  --fail-fast        Stop on first check failure

Output:
  stdout: JSON summary with check_results, reason codes, and timing
  stderr: Per-check progress (always printed)

Exit codes:
  0 — all checks passed (or were skipped in dev mode)
  1 — one or more actionable gate failures

Environment:
  GATE_CHECK_TIMEOUT_SEC  Per-check timeout in seconds (default: 30). |
| local-ci.sh | # HELP-TEXT-BEGIN
local-ci.sh — Run every gate the staging deploy-staging job depends on,
locally, in parallel where safe. |
| local-dev-down.sh | local-dev-down.sh — Tear down local dev services.

Kills flapjack, stops Docker Compose, cleans up PID/log files.
Idempotent: safe to run even when nothing is running.

Usage:
  scripts/local-dev-down.sh           # stop services, keep data
  scripts/local-dev-down.sh --clean   # stop services and remove volumes. |
| local-dev-migrate.sh | local-dev-migrate.sh — Apply database migrations for local development.

Prerequisites: source .env.local first to set DATABASE_URL.
Not safely rerunnable — migrations are not uniformly idempotent.
To reset, drop the database and re-create it before running again. |
| local-dev-up.sh | local-dev-up.sh — Start the local development environment.

Starts Docker Compose Postgres, runs migrations, starts Flapjack on port 7700,
and prints instructions for starting the API and web processes manually.

Prerequisites: docker, curl, .env.local at repo root.
Optional: FLAPJACK_DEV_DIR pointing to flapjack_dev repo. |
| local-signoff-cold-storage.sh | local-signoff-cold-storage.sh — Thin env bridge + cargo test delegate for
cold-storage integration signoff.

Resolves strict local stack defaults, validates cold-storage prerequisites,
delegates to the authoritative Rust integration test, and emits JSON +
operator-readable evidence.

Usage:
  ./scripts/local-signoff-cold-storage.sh. |
| local-signoff-commerce.sh | local-signoff-commerce.sh — Strict local commerce proof runner.

Exercises the full local commerce lane: signup -> email verification ->
batch billing -> invoice payment. |
| local-signoff.sh | local-signoff.sh — Top-level orchestrator that delegates to commerce,
cold-storage, and HA proof-owner scripts in strict order.

Does NOT duplicate proof-owner internals — only calls the three scripts
and interprets exit codes/output. |
| local_demo.sh | One-command local demo launcher: infra + API + web + seed data + metering. |
| playwright_local_stack.sh | playwright_local_stack.sh — Start local API + web for Playwright runs. |
| probe_alert_delivery.sh | Stub summary for probe_alert_delivery.sh. |
| probe_cloudflare_ai_block.sh | Read-only Cloudflare AI-bot-protection probe. |
| probe_deployed_signup_renders.sh | Stub summary for probe_deployed_signup_renders.sh. |
| probe_live_state.sh | scripts/probe_live_state.sh — fjcloud realization of Live State Discipline.

Per-project read-only inventory probe. |
| probe_organic_alert_dispatch.sh | Stub summary for probe_organic_alert_dispatch.sh. |
| probe_ses_bounce_complaint_e2e.sh | Stub summary for probe_ses_bounce_complaint_e2e.sh. |
| probe_ses_simulator_send.sh | Send-only SES mailbox simulator probe for bounce/complaint proof. |
| run-aggregation-job.sh | run-aggregation-job.sh — Run the aggregation job for a target date.

Rolls up raw usage_records into daily aggregates in usage_daily.
Idempotent — safe to run multiple times for the same date.
Defaults to yesterday (UTC) when no date argument is provided.

Usage:
  scripts/run-aggregation-job.sh                # yesterday
  scripts/run-aggregation-job.sh 2026-03-27     # specific date. |
| seed_local.sh | seed_local.sh — Idempotent local development seed script.

Creates a test user, index, and optionally seeds search data.
Safe to run multiple times — skips resources that already exist.

Usage:
  ./scripts/seed_local.sh              # uses defaults from .env.local
  API_URL=http://localhost:3001 ADMIN_KEY=my-key ./scripts/seed_local.sh. |
| seed_operator_accounts.sh | Stub summary for seed_operator_accounts.sh. |
| staging_billing_dry_run.sh | Stub summary for staging_billing_dry_run.sh. |
| staging_billing_rehearsal.sh | staging_billing_rehearsal.sh — guarded staging billing mutation rehearsal. |
| start-metering.sh | start-metering.sh — Start the metering agent for local dev.

Must run AFTER seed_local.sh (needs a real customer UUID from the database).
The metering agent scrapes Flapjack /metrics, computes deltas, and writes
usage_records to Postgres. |
| stripe_cutover_prereqs.sh | Stub summary for stripe_cutover_prereqs.sh. |
| stripe_webhook_replay_fixture.sh | Stub summary for stripe_webhook_replay_fixture.sh. |
| validate-metering.sh | Validate metering pipeline health against a live database and emit JSON. |
| validate-stripe.sh | Stub summary for validate-stripe.sh. |
| validate_customer_quickstart.sh | Stub summary for validate_customer_quickstart.sh. |
| validate_full_vm_lifecycle_prod.sh | Stub summary for validate_full_vm_lifecycle_prod.sh. |
| validate_inbound_email_roundtrip.sh | Validate SES outbound-to-inbound roundtrip for the shared test inbox path. |
| validate_oauth_routes.sh | Stub summary for validate_oauth_routes.sh. |
| validate_ses_readiness.sh | Stub summary for validate_ses_readiness.sh. |
| validate_staging_dunning_delivery.sh | Validate staging dunning email delivery by reusing rehearsal artifacts and SES inbound S3 evidence. |
| validate_subprocessor_disclosure.sh | Stub summary for validate_subprocessor_disclosure.sh. |
| web-dev.sh | web-dev.sh — Start the SvelteKit dev server with repo-local auth env loaded. |

| Directory | Summary |
| --- | --- |
| canary | The canary directory contains synthetic monitoring scripts and contract validation tests that continuously verify fjcloud infrastructure health, including customer workflow probes, external service availability checks, email deliverability, and integration points across the API, frontend, and AWS infrastructure. |
| chaos | The chaos directory contains failure-injection and HA resilience test scripts that validate the system's ability to detect outages, trigger failover, and recover—including region kill/restart tests, metering service failure detection, and end-to-end failover proofs. |
| launch | The launch directory contains deployment verification and evidence-capture scripts for the fjcloud staging environment, including tenant-map validation, synthetic traffic seeding, post-deploy verification gates, SSM environment hydration, and E2E test orchestration. |
| lib | This is a collection of reusable bash script libraries providing shared contracts for alerting, database operations, validation gates, Stripe/SES integration, environment configuration, and infrastructure health checks across the fjcloud project. |
| load | The load directory contains regression checking utilities for validating load testing performance, including scripts that compare offline and live load harness results to detect performance regressions. |
| reliability | This directory provides backend reliability profiling scripts, security validation gates (cargo audit, secret scanning, unsafe code detection), and test data seeding utilities that measure API capacity across three document-scale tiers and produce machine-readable JSON summaries. |
| stripe | The stripe directory contains operational scripts for managing Stripe integration with fjcloud: configuring the Customer Portal and creating the canonical Flapjack product catalog, both supporting multi-account operations. |
| tests | The tests directory contains shell-based integration test suites for ops-layer validation, including smoke tests for customer broadcast functionality and SES bounce/complaint probes, alongside a comprehensive lib/ of shared testing utilities, assertion helpers, and specialized harnesses for billing rehearsal, budget validation, and chaos testing scenarios. |
| vlm | The vlm directory contains Vision Language Model judge operations, including scripts to run and aggregate verdict bundles and shell utility libraries for environment configuration and prompt generation in the VLM judging system. |
| w3_triage | The w3_triage directory implements a multi-stage triage pipeline that bootstraps from live state probes, parses audit recommendations, applies rules, and emits dispatch manifests to orchestrate downstream lane execution. |
<!-- [scrai:end] -->
