This transport snapshot was redacted during posthoc security review.
Reason: the original archive embedded local secret-file paths and placeholder secret material.
Scope preserved: filename and evidence slot remain intact.
